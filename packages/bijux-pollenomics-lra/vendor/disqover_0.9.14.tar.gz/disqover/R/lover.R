#' LOVEr
#'
#' The LOVE model (LOcal Vegetation Estimates), introduced by Shinya Sugita
#' (2007), aims to translate pollen data from small sites into local
#' vegetation composition. The model assumes that pollen deposition in small
#' basins is composed of local pollen deposition from the nearby vegetation and
#' regional pollen deposition from farther away. A key assumption for the LOVE
#' model is that regional pollen deposition is uniform across a region.
#'
#' The present implementation of the LOVE model in R is based on equation 6 and
#' 7 from Sugita (2007), with three small adaptations. Pollen dispersal factors
#' g(z) are calculated using the ‘DispersalFactorK’ function from the ‘disqover’
#' R package. Regional vegetation estimates are calculated with the REVEALSinR
#' function, also from the ‘disqover’ R package. Finally, error estimates are
#' produced by repeated model runs, with random noise added in the regional and
#' local pollen counts and in the pollen productivity estimates during each run.
#' For further details, consult Theuerkauf & Couwenberg (2024).
#'
#' To estimate local vegetation composition, the LOVE model requires pollen
#' data from one small site and from a nearby large lake. Pollen deposition in
#' both the small and the large site should be exclusively
#' atmospheric, which means that the sites should not have major inflows. To
#' minimize any disturbing effects from the shore vegetation, the large lake
#' should be circular.
#'
#' The LOVEr function calculates local vegetation composition from one pair of
#' local and regional pollen data. Too apply LOVE for multiple samples, apply
#' LOVEr in a loop.
#'
#' Key parameters of LOVE application are 'relative pollen productivity
#' estimates' (known as PPEs or RPPs) to account for the differential pollen
#' productivity and the fall speed of pollen for each pollen taxon to account
#' for differential pollen dispersal. For the calculation of distance weighting
#' factors, a suitable dispersal model should be chosen.
#'
#'
#' @param pollenLoc a dataframe of the raw pollen counts from the small site.
#'   Counts are arranged with pollen taxa in columns and samples in rows.
#'   Taxon names cannot include spaces! For each pollen taxon, fallspeed and
#'   PPEs have to be provided in the parameters.
#' @param pollenReg a dataframe of the raw pollen counts from the large lake.
#'   Counts are arranged with pollen taxa in columns and samples in rows. The same
#'   taxa must be same as for the local data, ideally local and regional data are
#'   all included in the same dataframe (see example dataset LOVEexamplePollen)
#' @param lParams EDIT: a list of parameters needed for LOVEoptim application
#'   the fallspeed of pollen in m s-1 ('fallspeed'), relative pollen productivity
#'   estimates ('ppe') and their standard error ('ppe.error'). Pollen taxa are
#'   given in rows, parameters in columns. See example dataset 'LOVEexampleParams'.
#' @param dfRadii EDIT: dataframe describing ring sizes
#' @param maxRingLove maximum number of rings that is included in the calculations
#' @param repeats number of repeated model runs
#'
#' @return LOVEr returns 4 data frames that the reconstructed abundances and 2
#' data frames that are suited for evaluation.
#' @return ...Mean:	mean of the resulting cover estimates
#' @return ...Q10: 10\% quantile of the resulting cover estimates
#' @return ...Q90: 90\% quantile of the resulting cover estimates
#' @return ...SD: standard deviation of the resulting cover estimates
#' @return ...Outlier:	mean number of resulting cover values that are too small (<0) or too large (>1)
#' @return ...OutlierQuant: the number of resulting cover values that are too small (<0) or too large (>1),
#' but considering the 10\% and 90\% quantiles
#'
#'
#' @author Martin Theuerkauf <martin.theuerkauf@greifswaldmoor.de>
#' @references Sugita, S. (2007) Theory of quantitative reconstruction of vegetation II:
#'   all you need is LOVE. The Holocene 17, 243–257.
#'   https://doi.org/10.1177/0959683607075838
#'
#'   Theuerkauf, M., Couwenberg, J. (2024) LOVE is in in the R – Two R tools
#'   for local vegetation reconstruction. Quaternary.
#'
#' @examples \dontrun{
#' ## Example application with simulated data from Theuerkauf & Couwenberg (2024).
#' ## The dataset includes three part
#'
#' data(LOVEexamplePollen, package = "disqover") # pollen data
#' data(LOVEexampleParams, package = "disqover") # parameters
#' data(LOVEexampleRings, package = "disqover") #ring data
#'
#'
#' ## apply LOVEr...
#' dfResults <- LOVEr(pollenLoc = cbind(age = 1, LOVEexamplePollen['local',]),
#'       pollenReg = cbind(age = 1, LOVEexamplePollen['regional',]),
#'       lParams = LOVEexampleParams,
#'       dfRadii = LOVEexampleRings,
#'       maxRingLove = 35)
#' }
#'
#' @export

################################################################################
### LOVEr function
################################################################################


LOVEr <- function(pollenLoc, pollenReg, lParams, dfRadii, maxRingLove, repeats = 100){


  ################################################################################
  ### prepare variables
  ################################################################################

  # just rename
  vSampleLoc <- pollenLoc
  vSampleReg <- pollenReg

  nTaxa  <- length(vSampleLoc[-1])

  # prepare variables for data
  aLover <- array(0, dim = c(nTaxa, maxRingLove, repeats))
  dimnames(aLover) <- list(lParams$ppes$Taxon, dfRadii$mean[1:maxRingLove],1:repeats)

  mToosmall <- matrix(data = 0, ncol = repeats, nrow = maxRingLove)
  mToolarge <- matrix(data = 0, ncol = repeats, nrow = maxRingLove)


  ################################################################################
  ### calculate pollen dispersal deposition factor K for local and regional part
  ### = integral von g(z) in Sugita (2007), equation 7
  ################################################################################

  Kreg <- matrix(data = 0, nrow = maxRingLove, ncol = nTaxa)
  colnames(Kreg) <- lParams$ppes$Taxon
  rownames(Kreg) <- dfRadii$mean[1:maxRingLove]

  Kloc <- matrix(data = 0, nrow = maxRingLove, ncol = nTaxa)
  colnames(Kloc) <- lParams$ppes$Taxon
  rownames(Kloc) <- dfRadii$mean[1:maxRingLove]

  # j = 1
  for (j in 1:maxRingLove) {

    if (dfRadii$inner[j] > (lParams$dBasinLocal/2)){

      # calculate regional deposition factors (needed in the numerator of equation 7)
      # tBasin is always peatland --> there is no mixing assumed
      # EDIT: --> but what is against using the lake model? its adjusted to very small rings?
      Kreg[j,] <- do.call(rbind,lapply(lParams$fallspeed$fallspeed, DispersalFactorK, tBasin='peatland',
                                   dBasin=dfRadii$outer[j], dwm=lParams$dwm, regionCutoff = 1e5))

      # calculate local deposition factors from the set basin margin to the 'rsap'
      # (needed in the denominator of equation 7)
      Kloc[j,] <- do.call(rbind,lapply(lParams$fallspeed$fallspeed, DispersalFactorK, tBasin='peatland',
                                   dBasin=lParams$dBasinLocal, dwm=lParams$dwm, regionCutoff=dfRadii$outer[j]))

    }
  }



  ################################################################################
  # repeat calculations, by default 100 times, to determine confidence intervals
  ################################################################################
  # i = 1
  for (i in 1:repeats){


    ################################################################################
    ### apply REVEALS
    ################################################################################

    # calculate regional vegetation composition with REVEALS (noise will automatically added to counts and PPEs)
    # EDIT: regionCutoff still needed as a parameter? (now the default value is used)
    lCoverReg <- REVEALSinR(pollen=vSampleReg, params = lParams$ppes, dwm=lParams$dwm, tBasin=lParams$tBasinRegional,
                        dBasin=lParams$dBasinRegional, n = 1, verbose = FALSE)

    # extract mean values = V hat
    vr <- lCoverReg[ , grepl("mean", names(lCoverReg) )] / 100  # v hat from equation 7



    ################################################################################
    ###   loop radii, apply LOVE in each step
    ################################################################################
    j=10
    for (j in 1:maxRingLove) {

      # just a message
      cat('\rModel run:', i,' Radius:', dfRadii$inner[j], '-',dfRadii$outer[j],'\t')

      ### check whether ring is outside the basin
      ### if not - skip this ring
      if (dfRadii$inner[j] > (lParams$dBasinLocal/2)){

        # calculate the s hat in equation 7 from Sugita 2007
        # calculate denominator of equation 7
        s_bot <- sum(vr * Kloc[j,])

        # and now the numerator
        s_top <- vr * Kreg[j,]

        # and now s hat
        sr <- s_top / s_bot

        # call the 'lov' function with the actual calculations from Sugita 2007
        l <- lov(vSampleLoc, sr, lParams)

        aLover[,j,i] <- unlist(l)

        mToosmall[j,i] <- sum(l < 0)
        mToolarge[j,i] <- sum(l > 1)

      } else {

        # for rings smaller than the basin --> add NA values
        aLover[,j,i] <- NA

        mToosmall[j,i] <- NA
        mToolarge[j,i] <- NA
      }
    }
  }


  # calculate mean of the resulting cover estimates
  mLoverMean <- t(apply(aLover, MARGIN = 1:2, mean, na.rm = TRUE))
  # colnames(mLoverMean) <- lParams$ppes$Taxon
  # rownames(mLoverMean) <- dfRadii$mean[1:maxRingLove]

  # calculate Q10 of the resulting cover estimates
  mLoverQ10 <- t(apply(aLover, MARGIN = 1:2, quantile, probs = 0.10, na.rm = TRUE))
  # colnames(mLoverQ10) <- lParams$ppes$Taxon
  # rownames(mLoverQ10) <- dfRadii$mean[1:maxRingLove]

  # calculate Q90 of the resulting cover estimates
  mLoverQ90 <- t(apply(aLover, MARGIN = 1:2, quantile, probs = 0.90, na.rm = TRUE))
  # colnames(mLoverQ90) <- lParams$ppes$Taxon
  # rownames(mLoverQ90) <- dfRadii$mean[1:maxRingLove]

  # calculate SD of the resulting cover estimates (SD is possibly not that meaningful)
  mLoverSd <- t(apply(aLover, MARGIN = 1:2, sd, na.rm = TRUE))
  # colnames(mLoverSd) <- lParams$ppes$Taxon
  # rownames(mLoverSd) <- dfRadii$mean[1:maxRingLove]

  # calculate the number of resulting cover values that are too small (<0) or too large (>1)
  lOut <- apply((mToosmall + mToolarge),1, mean)
  names(lOut) <- dfRadii$mean[1:maxRingLove]


  # calculate the number of resulting cover values that are too small (<0) or too large (>1), now considering
  # the 10% and 90% quantile of the cover estimates (i.e. check whether at least the quantiles are within the
  # range of 0 to 1)
  mOutQuant <- matrix(0, nrow = maxRingLove, ncol = nTaxa)
  for(x in 1:maxRingLove){
    for(y in 1:nTaxa){
      test1 <- mLoverQ10[x,y] >= 0 &  mLoverQ10[x,y] <= 1
      test2 <- mLoverQ90[x,y] >= 0 &  mLoverQ90[x,y] <= 1

      if(is.na(test1)){
        mOutQuant[x,y] <- NA
      } else if ((test1 == FALSE) & (test2 == FALSE)){
        mOutQuant[x,y] <- 1
      } else {
        mOutQuant[x,y] <- 0
      }
    }
  }

  lOutQuant <- rowSums(mOutQuant)
  names(lOutQuant) <- dfRadii$mean[1:maxRingLove]

  return(list(Mean = mLoverMean, Q10 = mLoverQ10, Q90 = mLoverQ90, SD = mLoverSd,
              Outlier = lOut, OutlierQant = lOutQuant))

}


############################################################
# LOVE model equation 6 with noise added in counts and PPEs
############################################################

lov <- function(vSampleLoc, sr, lParams){

  # add random error to pollen productivity (using mean and standard deviation)
  # 'while loop' needed to avoid negative values
  if (lParams$error){
    alpha <- disqover:::rnorm_reveals(length(lParams$ppes$ppe), lParams$ppes$ppe, lParams$ppes$ppe.error)
  } else {
    alpha <- lParams$ppes$ppe
  }

  # apply alpha as weighting factor for local counts, if error=TRUE then add noise
  if (lParams$error){
    vSampleLoc <- rmultinom(1, sum(vSampleLoc[,-1]), vSampleLoc[,-1]/sum(vSampleLoc[,-1]))
    i <- vSampleLoc/alpha
  } else {
    i <- vSampleLoc[,-1]/alpha
  }

  irel <- i/sum(i)

  # equation 6 in Sugita 2007
  x <- irel * (1 + sum(sr))
  fin <- irel * (1 + sum(sr)) - sr
  return(fin)

}





